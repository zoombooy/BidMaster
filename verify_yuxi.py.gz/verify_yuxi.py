"""在 Yuxi api-prod 运行时内，按平台调用路径验证 BidMaster MCP。"""
import asyncio, json

async def main():
    from langchain_mcp_adapters.client import MultiServerMCPClient
    client = MultiServerMCPClient({
        'bidmaster': {'url': 'http://172.19.136.137:8200/mcp',
                      'transport': 'streamable_http'}})
    tools = await client.get_tools()
    print('[1] Yuxi 运行时加载 MCP 工具:', [t.name for t in tools])

    analyze = [t for t in tools if t.name == 'analyze_tender'][0]
    result = await analyze.ainvoke({'local_path': '/app/tender.zip', 'use_llm': False})
    text = ''.join(b.get('text', '') for b in result) if isinstance(result, list) else str(result)
    data = json.loads(text)
    st = data['stats']
    print('[2] 真实招标整包解析完成')
    print('    评分项:', st['score_items'], '| 要求条目:', st['requirements'],
          '| 字段:', st['fields_found'], '/', st['fields_total'],
          '| 废标风险:', len(data.get('rejection_risks', [])))

    print('[3] 关键字段质量:')
    for k in ('project_name', 'tender_no', 'price_limit', 'bid_deadline',
              'security_deposit', 'evaluation_method'):
        v = data['fields'].get(k, {})
        mark = 'OK ' if v.get('status') == 'found' else 'MISS'
        print(f"    [{mark}] {k:<20} {str(v.get('value'))[:44]}")

    print('[4] 评分项样例:', json.dumps(data['score_items'][:3], ensure_ascii=False))
    print('[5] 废标样例:', json.dumps(data.get('rejection_risks', [])[:2], ensure_ascii=False))

    get_report = [t for t in tools if t.name == 'get_report'][0]
    rep = await get_report.ainvoke({'doc_id': data['doc_id']})
    t2 = ''.join(b.get('text', '') for b in rep) if isinstance(rep, list) else str(rep)
    full = json.loads(t2)
    ok = sum(1 for c in full.get('sum_checks', []) if c.get('ok'))
    print(f"[6] get_report 完整报告: {len(t2)} 字符 | 分值校验 {ok}/{len(full.get('sum_checks', []))} 组通过")

asyncio.run(main())
