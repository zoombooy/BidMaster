docker logs api-prod --since 40m 2>&1 | grep -B3 -A12 "agents" | grep -iE "error|raise|File|validation|missing|KeyError" | head -15
echo "=== 完整 traceback 定位 ==="
docker logs api-prod --since 40m 2>&1 | grep -A20 "Traceback" | tail -25
