docker rm -f bidmaster-yuxi-api
docker run -d --name bidmaster-yuxi-api --restart unless-stopped \
  -v /opt/apps/bidmaster-yuxi/app:/app \
  -v /opt/apps/Yuxi/docker/volumes/yuxi/threads/shared/admin/workspace:/home/gem/user-data \
  -w /app \
  -e BIDMASTER_ALLOWED_PATHS="/home/gem/user-data" \
  -p 8200:8200 --entrypoint bash oliveira-api:latest \
  -c "pip install --no-index --find-links=/app/wheels -r requirements.txt -q && python -m uvicorn bidmaster.api.main:app --host 0.0.0.0 --port 8200"
sleep 15
echo "=== 容器内可见性 ==="
docker exec bidmaster-yuxi-api ls /home/gem/user-data/projects/2026-09-27_08-41-48_09ed9fe5/uploads/ 2>&1
curl -s -m 5 http://127.0.0.1:8200/healthz
