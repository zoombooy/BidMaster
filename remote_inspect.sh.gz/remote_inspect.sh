SANDBOX=$(docker ps -a --format "{{.Names}}" | grep -iE "sand|gem" | head -3)
echo "相关容器: $SANDBOX"
for s in $SANDBOX; do
  echo "--- $s ---"
  docker inspect "$s" --format "{{range .Mounts}}{{.Source}} -> {{.Destination}}{{println}}{{end}}" | grep -E "gem|user-data" | head -4
done
echo "=== api-prod 内部视角 ==="
docker exec api-prod sh -c "ls /home/gem/user-data/projects 2>/dev/null | tail -2 || echo api-prod 无此路径"
echo "=== 宿主机找 user-data ==="
ls -d /var/lib/docker/volumes/*gem* /var/lib/docker/volumes/*user* 2>/dev/null | head -5
