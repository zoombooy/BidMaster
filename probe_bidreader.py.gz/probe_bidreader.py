import urllib.request, json
TOKEN = 'd5e8eddab40544b3417e9e4369368193d5e2a0e7a50c3b2bec9d6458392e3f0d'
TID = '114f1345-b7f2-434d-9449-a18fd06baa56'
RUN = '6058ee13-631a-42e0-83e6-7f8b3913a0a3'
def call(name, args):
    req = urllib.request.Request(
        'http://127.0.0.1:8001/mcp',
        data=json.dumps({'jsonrpc':'2.0','id':1,'method':'tools/call',
                         'params':{'name':name,'arguments':args}}).encode(),
        headers={'Content-Type':'application/json',
                 'Accept':'application/json, text/event-stream',
                 'Authorization':'Bearer '+TOKEN})
    r = urllib.request.urlopen(req, timeout=90)
    raw = r.read().decode('utf-8')
    if raw.startswith('event:') or '\ndata:' in raw:
        for line in raw.splitlines():
            if line.startswith('data:'):
                raw = line[5:].strip(); break
    d = json.loads(raw)
    return ''.join(c.get('text','') for c in d['result'].get('content', []) if isinstance(c, dict))

summary = {}
for cat in ('technical', 'commercial', 'price', 'unclassified'):
    r = call('get_tender_analysis', {'tender_id': TID, 'run_id': RUN, 'category': cat})
    d = json.loads(r)
    keys = list(d.keys())
    info = {'顶层键': keys}
    for k in keys:
        v = d[k]
        if isinstance(v, list):
            info[k] = f'列表[{len(v)}] 示例: ' + json.dumps(v[0], ensure_ascii=False)[:200] if v else '空列表'
        elif isinstance(v, dict):
            info[k] = 'dict键: ' + ','.join(list(v.keys())[:12])
    summary[cat] = info
# 搜索三个关键词
for kw in ('最高限价', '服务期', '投标保证金'):
    r = call('search_tender_analysis', {'tender_id': TID, 'query': kw, 'limit': 2})
    summary['search_' + kw] = r[:400]
print(json.dumps(summary, ensure_ascii=False, indent=1)[:5000])
