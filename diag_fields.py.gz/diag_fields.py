import json
f4 = json.load(open('/app/work/5928273ca142/04_fields.json', encoding='utf-8'))['fields']
r6 = json.load(open('/app/work/5928273ca142/06_report.json', encoding='utf-8'))['fields']
print('04 字段数:', len(f4), '| 06 字段数:', len(r6))
print('仅04有:', sorted(set(f4) - set(r6)))
print('仅06有:', sorted(set(r6) - set(f4)))
print()
print('06 中 value=null 的 found 字段:')
for k, v in r6.items():
    if v.get('status') == 'found' and v.get('value_normalized') is None:
        print(' ', k, '| sources:', [c.get('source') for c in v.get('candidates', [])], '| note:', str(v.get('note', ''))[:60])
