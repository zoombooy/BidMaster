echo "=== 1. bidmaster 收到的 MCP 请求日志 ==="
docker logs bidmaster-yuxi-api 2>&1 | grep -E "POST /mcp" | tail -5
echo "=== 2. 本次解析的工作区产物 ==="
docker exec bidmaster-yuxi-api sh -c "ls /app/work/ | grep cce36b879e3b && ls /app/work/cce36b879e3b/"
echo "=== 3. 报告里的 LLM 状态与关键统计 ==="
docker exec bidmaster-yuxi-api python - <<'PY'
import json
r = json.load(open('/app/work/cce36b879e3b/06_report.json', encoding='utf-8'))
print('doc_id:', r['doc_id'])
print('stats.llm:', r['stats'].get('llm'))
print('stats:', {k: v for k, v in r['stats'].items() if k in ('fields_found','fields_total','score_items','requirements')})
print('sum_checks:', len(r.get('sum_checks', [])), '| rejections:', len(r.get('rejections', [])))
PY
echo "=== 4. 容器环境变量（LLM 是否配置） ==="
docker exec bidmaster-yuxi-api sh -c 'env | grep -c BIDMASTER_LLM || echo 0'
