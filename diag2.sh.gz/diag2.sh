echo "=== 1. 新项目文件是否存在（宿主机共享卷） ==="
ls -la "/opt/apps/Yuxi/docker/volumes/yuxi/threads/shared/admin/workspace/projects/2026-09-27_09-27-01_a64310c4/uploads/" 2>&1 | head -5
echo "=== 2. bidmaster 容器内可见性 ==="
docker exec bidmaster-yuxi-api sh -c "ls /home/gem/user-data/projects/2026-09-27_09-27-01_a64310c4/uploads/ 2>&1 | head -3"
echo "=== 3. bidmaster 服务日志（有无收到 MCP 调用） ==="
docker logs bidmaster-yuxi-api --since 3h 2>&1 | grep -E "POST /mcp|POST /api" | tail -6
echo "=== 4. api-prod 日志中的错误 ==="
docker logs api-prod --since 3h 2>&1 | grep -iE "error|exception|bidmaster|streaming" | tail -12
