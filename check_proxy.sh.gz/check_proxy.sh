echo "=== api-prod 代理相关环境变量 ==="
docker exec api-prod sh -c 'env | grep -iE "proxy" '
echo "=== worker-prod ==="
docker exec worker-prod sh -c 'env | grep -iE "proxy"' 2>/dev/null | head -6
echo "=== compose 里的 proxy 配置 ==="
grep -rn -iE "proxy" /opt/apps/Yuxi/docker-compose*.yml 2>/dev/null | head -10
ls /opt/apps/Yuxi/*.yml /opt/apps/Yuxi/docker/*.yml 2>/dev/null | head -5
