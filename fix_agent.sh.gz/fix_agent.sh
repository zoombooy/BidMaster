docker exec postgres psql -U postgres -d yuxi -c "\d agents" 2>&1 | head -40
echo "=== 现有智能体 ==="
docker exec postgres psql -U postgres -d yuxi -c "SELECT slug, name FROM agents LIMIT 8;"
