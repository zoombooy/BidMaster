echo "=== 全部容器（找沙盒） ==="
docker ps -a --format "{{.Names}}" | head -40
echo "=== threads 卷内容 ==="
ls /opt/apps/Yuxi/docker/volumes/yuxi/threads/ 2>/dev/null | tail -5
echo "=== 目标项目目录 ==="
find /opt/apps/Yuxi/docker/volumes/yuxi -type d -name "*09ed9fe5*" 2>/dev/null | head -3
ls /opt/apps/Yuxi/docker/volumes/yuxi/threads/2026-09-27_08-41-48_09ed9fe5 2>/dev/null
