docker rm -f bidmaster-yuxi-api
docker run -d --name bidmaster-yuxi-api --restart unless-stopped \
  -v /opt/apps/bidmaster-yuxi/app:/app \
  -v /opt/apps/Yuxi/docker/volumes/yuxi/threads/shared:/home/gem/user-data \
  -w /app \
  -e BIDMASTER_ALLOWED_PATHS="/home/gem/user-data" \
  -p 8200:8200 --entrypoint bash oliveira-api:latest \
  -c "pip install --no-index --find-links=/app/wheels -r requirements.txt -q && python -m uvicorn bidmaster.api.main:app --host 0.0.0.0 --port 8200"
sleep 15
curl -s -m 5 http://127.0.0.1:8200/healthz
echo
# 把真实招标包放进用户上传目录，模拟"用户在界面上传"
mkdir -p /opt/apps/Yuxi/docker/volumes/yuxi/threads/shared/admin/workspace/projects/2026-09-27_08-41-48_09ed9fe5/uploads
cp /opt/apps/bidmaster-yuxi/app/tender.zip /opt/apps/Yuxi/docker/volumes/yuxi/threads/shared/admin/workspace/projects/2026-09-27_08-41-48_09ed9fe5/uploads/tender.zip
ls -la /opt/apps/Yuxi/docker/volumes/yuxi/threads/shared/admin/workspace/projects/2026-09-27_08-41-48_09ed9fe5/uploads/
