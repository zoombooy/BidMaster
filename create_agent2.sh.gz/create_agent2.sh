echo "=== 1. 创建专用智能体 ==="
cat <<'SQL' | docker exec -i postgres psql -U postgres -d yuxi
INSERT INTO agents (slug, backend_id, name, description, icon, pics, config_json, share_config, is_default, is_subagent, created_by, updated_by, created_at, updated_at)
VALUES ('tender-analysis', 'tender-analysis-backend', '招标文件解析助手',
 '解析招标文件（docx/pdf/xlsx/zip 整包，支持扫描件 OCR）。输出：限价/工期/保证金等关键字段（带原文证据页码）、技术/商务评分项、业绩/项目负责人/人员配备要求、★条款与废标风险清单。用户上传文件后直接说"解析我上传的招标文件"即可。',
 '📋', '[]',
 '{"context": {"system_prompt": "你是招标文件解析助手。用户上传招标文件或给出文件路径后，调用 bidmaster MCP 的 analyze_tender 工具（local_path=文件路径）。用户在界面上传的文件位于 /home/gem/user-data/projects/<项目>/uploads/ 下，可直接作为 local_path 使用，不要用 shell 读取该路径。解析后按以下结构汇报：1.关键字段（项目名称/编号/限价/工期/保证金，注明证据页码）；2.评分项按 技术/商务/价格 分类列出名称与分值；3.废标风险条数与要点；4.提示可用 get_report 获取完整报告。只用工具返回的数据回答，不要编造。", "model": "deepseek:deepseek-v4-flash", "tools": ["ask_user_question"], "knowledges": null, "mcps": ["bidmaster"], "skills": [], "summary_threshold": 100, "summary_keep_messages": 10}',
 '{}', false, false, 'admin', 'admin', NOW(), NOW())
ON CONFLICT (slug) DO UPDATE SET config_json = EXCLUDED.config_json, updated_at = NOW();
SQL
echo "=== 2. 全库搜错误模型配置来源 ==="
cat <<'SQL' | docker exec -i postgres psql -U postgres -d yuxi -t
SELECT 'threads' AS tbl, id::text FROM threads WHERE config::text LIKE '%DeepSeek-V4-Flash%' LIMIT 3;
SQL
docker exec postgres psql -U postgres -d yuxi -c "SELECT slug, config_json->'context'->>'model' AS model FROM agents WHERE slug='tender-analysis';"
echo "=== 3. 最近 threads 的模型配置 ==="
docker exec postgres psql -U postgres -d yuxi -c "SELECT column_name FROM information_schema.columns WHERE table_name='threads';" | head -15
