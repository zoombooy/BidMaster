echo "=== 1. 全盘找 soffice/libreoffice（宿主机+常见镜像内） ==="
find / -name "soffice" -o -name "libreoffice" 2>/dev/null | grep -v proc | head -5
for img in oliveira-api:latest web-prod:latest api-prod:latest snailai-server-1:latest; do
  docker exec $img sh -c 'command -v soffice libreoffice 2>/dev/null' 2>/dev/null | head -1
done
echo "（以上无输出=都没有）"
echo "=== 2. 内网镜像连通性 ==="
for h in mirrors.cloud.aliyuncs.com mirrors.aliyun.com; do
  curl -s -m 5 -o /dev/null -w "$h: %{http_code}\n" "https://$h" 2>/dev/null || echo "$h: 不通"
done
echo "=== 3. yum 仓库状态 ==="
yum repolist 2>/dev/null | head -5
echo "=== 4. 容器内 pip 阿里镜像连通性 ==="
docker exec bidmaster-yuxi-api pip download olefile -d /tmp/t --no-deps -i https://mirrors.aliyun.com/pypi/simple/ -q 2>&1 | tail -1
ls /tmp/t 2>/dev/null | head -2
