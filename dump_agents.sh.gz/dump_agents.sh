docker exec postgres psql -U postgres -d yuxi -t -c "SELECT config_json FROM agents WHERE slug='default-chatbot';" | head -c 1500
